const APIkey = "6a611cbbc067f28467313d9fe9cda0ae";
const APIurl = "https://api.openweathermap.org/data/2.5/weather?units=metric&q=";
//const cityName = document.getElementsByName("input");
const searchBox = document.querySelector(".search input")
const searchButton = document.querySelector(".search button")
const WeatherIcon = document.querySelector(".iconnn")


async function checkWeather(cityName) {
    const res = await fetch(APIurl + cityName + `&appid=${APIkey}`);
    let data = await res.json();

    console.log(data);
    document.querySelector(".city").innerHTML = data.name;
    document.querySelector(".temp").innerHTML = Math.round(data.main.temp) + "°c";
    document.querySelector(".humudity").innerHTML = data.main.humidity + "%";
    document.querySelector(".wind").innerHTML = data.wind.speed + " km/h";

    if (data.weather[0].main == "Clouds") {
        WeatherIcon.src = "cloud.png";
    } else if (data.weather[0].main == "Clear") {
        WeatherIcon.src = "sunny.png";
    } else if (data.weather[0].main == "Rain") {
        WeatherIcon.src = "umbrella.png";
    } else if (data.weather[0].main == "Drizzle") {
        WeatherIcon.src = "raining.png";
    } else if (data.weather[0].main == "Mist") {
        WeatherIcon.src = "mist.png";
    }

    document.querySelector(".weather").style.display = "block";

}




searchBox.addEventListener('keypress', function (event) {
    if (event.key === "Enter") {  // Only run when Enter key is pressed
        checkWeather(searchBox.value);
    }
});


searchButton.addEventListener("click", function () {
    checkWeather(searchBox.value);
})
checkWeather()

